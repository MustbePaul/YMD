from flask import Flask, render_template, request, redirect, url_for, session
from flask_bcrypt import Bcrypt
from flask_mysqldb import MySQL
import MySQLdb.cursors
import os
import base64
from random import randint
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from email.mime.text import MIMEText
from datetime import timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Replace with a secure secret key

bcrypt = Bcrypt(app)

# MySQL configurations
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'  # Hardcoded MySQL username
app.config['MYSQL_PASSWORD'] = '123'  # Hardcoded MySQL password
app.config['MYSQL_DB'] = 'banking'  # Name of your MySQL database

mysql = MySQL(app)

# Scopes required by the Gmail API
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

def send_verification_email(recipient_email, verification_code):
    try:
        creds = None
        if os.path.exists('token.json'):
            creds = Credentials.from_authorized_user_file('token.json', SCOPES)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                BASE_DIR = os.path.dirname(os.path.abspath(__file__))
                credentials_path = os.path.join(BASE_DIR, 'credentials.json')
                flow = InstalledAppFlow.from_client_secrets_file(credentials_path, SCOPES)
                creds = flow.run_local_server(port=0)

            with open('token.json', 'w') as token:
                token.write(creds.to_json())

        service = build('gmail', 'v1', credentials=creds)
        subject = "Your Verification Code"
        body = f"Your verification code is: {verification_code}"
        message = MIMEText(body)
        message['to'] = recipient_email
        message['subject'] = subject
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
        sent_message = service.users().messages().send(userId="me", body={'raw': raw_message}).execute()
        logging.info(f"Verification email sent: {sent_message['id']}")
    except Exception as e:
        logging.error(f"An error occurred while sending email: {e}")

@app.route('/')
def home():
    return render_template('home.html')

# Registration Route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        account_number = request.form['account_number']  # Get account number from form
        balance = int(request.form['balance'])  # Capture and convert balance to int

        cursor = mysql.connection.cursor()

        # Insert user information into the users table
        cursor.execute('INSERT INTO users (username, email, password) VALUES (%s, %s, %s)', (username, email, password))
        mysql.connection.commit()

        # Get the user ID of the newly created user
        cursor.execute('SELECT id FROM users WHERE username = %s', [username])
        user_id = cursor.fetchone()['id']

        # Insert account information into the accounts table
        cursor.execute('INSERT INTO accounts (user_id, account_number, balance) VALUES (%s, %s, %s)', (user_id, account_number, balance))
        mysql.connection.commit()

        cursor.close()

        logging.info(f"New user registered: {username} with account number: {account_number} and balance: {balance}")
        return redirect(url_for('login'))

    return render_template('register.html')



# Login Route with 2FA
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        # Check if the username is in the admins table first
        cursor.execute('SELECT * FROM admins WHERE username = %s', [username])
        admin = cursor.fetchone()

        if admin:
            # If found in admins table, check the plaintext password
            if admin['password'] == password:
                session['username'] = admin['username']  # Store admin username in session
                session['is_admin'] = True  # Set an admin flag in the session
                return redirect(url_for('admin_dashboard'))  # Redirect to admin dashboard
            else:
                logging.warning(f"Invalid admin login attempt for user: {username}")
                return 'Invalid credentials!'
        else:
            # If not found in admins, check the users table
            cursor.execute('SELECT * FROM users WHERE username = %s', [username])
            user = cursor.fetchone()

            if user and bcrypt.check_password_hash(user['password'], password):
                # For users, generate a verification code for 2FA
                verification_code = randint(100000, 999999)
                session['verification_code'] = verification_code
                session['username'] = user['username']  # Store user username in session
                session.permanent = True  # Session will expire after some time
                app.permanent_session_lifetime = timedelta(minutes=10)  # Set session lifetime
                send_verification_email(user['email'], verification_code)
                return redirect(url_for('verify_2fa'))
            else:
                logging.warning(f"Invalid user login attempt for user: {username}")
                return 'Invalid credentials!'

    return render_template('login.html')

# 2FA Verification Route
@app.route('/verify_2fa', methods=['GET', 'POST'])
def verify_2fa():
    if request.method == 'POST':
        code = request.form['code']
        if int(code) == session['verification_code']:
            session['loggedin'] = True
            logging.info(f"User {session['username']} logged in successfully.")
            return redirect(url_for('dashboard'))
        else:
            logging.warning("Invalid verification code entered.")
            return 'Invalid verification code!'
    return render_template('verify_2fa.html')

# Dashboard Route
@app.route('/dashboard')
def dashboard():
    if 'loggedin' in session:
        username = session['username']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        # Fetch account information from the accounts table based on the user's username
        cursor.execute('''
            SELECT accounts.account_number, accounts.balance 
            FROM accounts 
            WHERE user_id = (SELECT id FROM users WHERE username = %s)
        ''', [username])

        account_info = cursor.fetchone()  # Fetch the account information

        cursor.close()

        # If no account information is found, proceed with an empty or default account_info
        if account_info is None:
            account_info = {
                'account_number': 'Not available',
                'balance': 'Not available'
            }

        return render_template('dashboard.html', account=account_info)

    return redirect(url_for('login'))

# admin_dashboard Route
@app.route('/admin_dashboard')
def admin_dashboard():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

    # Fetch all admins for the admin dashboard
    cursor.execute('SELECT * FROM admins')
    users = cursor.fetchall()

    # Fetch only transactions that are pending approval
    cursor.execute('SELECT * FROM transactions WHERE status = "pending"')
    transactions = cursor.fetchall()

    cursor.close()

    # Pass only the transactions and use session['username'] for admin username
    return render_template('admin_dashboard.html', transactions=transactions, users=users)


@app.route('/approve_transaction/<int:transaction_id>')
def approve_transaction(transaction_id):
    cursor = mysql.connection.cursor()

    # Update the transaction status to 'approved'
    cursor.execute('UPDATE transactions SET status = "approved" WHERE id = %s', (transaction_id,))

    # Optionally: Perform other necessary actions such as balance updates
    cursor.execute('SELECT from_account, to_account, amount FROM transactions WHERE id = %s', [transaction_id])
    transaction = cursor.fetchone()

    # Update balances for the accounts involved
    cursor.execute('UPDATE accounts SET balance = balance - %s WHERE account_number = %s',
                   (transaction['amount'], transaction['from_account']))
    cursor.execute('UPDATE accounts SET balance = balance + %s WHERE account_number = %s',
                   (transaction['amount'], transaction['to_account']))

    mysql.connection.commit()
    cursor.close()

    return redirect(url_for('admin_dashboard'))


@app.route('/reject_transaction/<int:transaction_id>')
def reject_transaction(transaction_id):
    cursor = mysql.connection.cursor()

    # Update the transaction status to 'rejected'
    cursor.execute('UPDATE transactions SET status = "rejected" WHERE id = %s', (transaction_id,))

    mysql.connection.commit()
    cursor.close()

    return redirect(url_for('admin_dashboard'))


# Profile Route
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'loggedin' in session:
        username = session['username']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        if request.method == 'POST':
            new_username = request.form['username']
            new_email = request.form['email']
            new_password = request.form['password']
            new_account_number = request.form['account_number']

            # Update user info
            cursor.execute('UPDATE users SET username = %s, email = %s WHERE username = %s',
                           (new_username, new_email, username))

            # Only update password if provided
            if new_password:
                cursor.execute('UPDATE users SET password = %s WHERE username = %s',
                               (bcrypt.generate_password_hash(new_password).decode('utf-8'), new_username))

            # Get the user ID for account updates
            cursor.execute('SELECT id FROM users WHERE username = %s', [new_username])
            user_id = cursor.fetchone()['id']

            # Check if the user has an existing account
            cursor.execute('SELECT * FROM accounts WHERE user_id = %s', [user_id])
            account = cursor.fetchone()

            if account:
                # Update existing account number if account already exists
                cursor.execute('UPDATE accounts SET account_number = %s WHERE user_id = %s',
                               (new_account_number, user_id))
            else:
                # If no account exists, insert new account information with default balance
                cursor.execute('INSERT INTO accounts (user_id, account_number, balance) VALUES (%s, %s, 0)',
                               (user_id, new_account_number))

            # Commit the changes to the database
            mysql.connection.commit()
            cursor.close()

            # Update session username if changed
            session['username'] = new_username
            logging.info(f"User profile updated: {new_username}")
            return redirect(url_for('dashboard'))

        # Fetch current user information for pre-filling the form
        cursor.execute('SELECT username, email FROM users WHERE username = %s', [username])
        user_info = cursor.fetchone()

        # Fetch account number if it exists, else provide a default empty value
        cursor.execute('SELECT account_number FROM accounts WHERE user_id = (SELECT id FROM users WHERE username = %s)', [username])
        account_info = cursor.fetchone()

        cursor.close()

        # Default account number if no account exists
        account_number = account_info['account_number'] if account_info else ""

        return render_template('profile.html', user=user_info, account_number=account_number)

    return redirect(url_for('login'))


# pay_bills Route
@app.route('/pay_bills', methods=['GET', 'POST'])
def pay_bills():
    if request.method == 'POST':
        from_account = request.form['from_account']
        biller = request.form['biller']
        amount = float(request.form['amount'])

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        # Check the balance of the 'from_account'
        cursor.execute('SELECT balance FROM accounts WHERE account_number = %s', [from_account])
        account_info = cursor.fetchone()
        balance = account_info['balance']

        # Check if the balance is zero or less
        if balance <= 0:
            # Mark the bill payment as a "credit" (negative balance)
            amount_to_credit = -amount  # Amount will be negative (credit)
            cursor.execute('UPDATE accounts SET balance = balance + %s WHERE account_number = %s',
                           (amount_to_credit, from_account))
            cursor.execute(
                'INSERT INTO transactions (from_account, to_account, amount, purpose, status) VALUES (%s, %s, %s, %s, %s)',
                (from_account, biller, amount_to_credit, 'Bill Payment', 'credit'))
        else:
            # Proceed with the normal bill payment (debit from sender)
            cursor.execute('UPDATE accounts SET balance = balance - %s WHERE account_number = %s',
                           (amount, from_account))
            cursor.execute(
                'INSERT INTO transactions (from_account, to_account, amount, purpose) VALUES (%s, %s, %s, %s)',
                (from_account, biller, amount, 'Bill Payment'))

        mysql.connection.commit()
        cursor.close()

        logging.info(f"Paid bill of {amount} from {from_account} to {biller}.")
        return redirect(url_for('dashboard'))

    return render_template('pay_bills.html')


@app.route('/transactions')
def transactions():
    if 'loggedin' in session:
        username = session['username']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        # Fetch the user's account number
        cursor.execute('''
            SELECT account_number FROM accounts 
            WHERE user_id = (SELECT id FROM users WHERE username = %s)
        ''', [username])
        account_info = cursor.fetchone()

        if account_info:
            account_number = account_info['account_number']

            # Fetch all transactions where the user's account is either the sender or the recipient
            cursor.execute('''
                SELECT id, from_account, to_account, amount, purpose, status, date 
                FROM transactions 
                WHERE from_account = %s OR to_account = %s 
                ORDER BY date DESC
            ''', (account_number, account_number))

            transactions = cursor.fetchall()
        else:
            transactions = []

        cursor.close()

        return render_template('transactions.html', transactions=transactions)

    return redirect(url_for('login'))




# Transfer Funds Route
@app.route('/transfer', methods=['GET', 'POST'])
def transfer():
    if 'loggedin' in session:
        if request.method == 'POST':
            from_account = request.form['from_account']
            to_account = request.form['to_account']
            amount = float(request.form['amount'])
            purpose = request.form['purpose']

            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            # Check the balance of the 'from_account'
            cursor.execute('SELECT balance FROM accounts WHERE account_number = %s', [from_account])
            account_info = cursor.fetchone()
            balance = account_info['balance']

            # Check if the balance is zero or less
            if balance <= 0:
                # Mark the transaction as a "credit" (negative balance)
                amount_to_credit = -amount  # Amount will be negative (credit)
                cursor.execute('UPDATE accounts SET balance = balance + %s WHERE account_number = %s',
                               (amount_to_credit, from_account))
                cursor.execute(
                    'INSERT INTO transactions (from_account, to_account, amount, purpose, status) VALUES (%s, %s, %s, %s, %s)',
                    (from_account, to_account, amount_to_credit, purpose, 'credit'))
            else:
                # Proceed with the normal transaction (debit from sender, credit to receiver)
                cursor.execute('UPDATE accounts SET balance = balance - %s WHERE account_number = %s',
                               (amount, from_account))
                cursor.execute('UPDATE accounts SET balance = balance + %s WHERE account_number = %s',
                               (amount, to_account))
                cursor.execute(
                    'INSERT INTO transactions (from_account, to_account, amount, purpose) VALUES (%s, %s, %s, %s)',
                    (from_account, to_account, amount, purpose))

            mysql.connection.commit()
            cursor.close()

            logging.info(f"Transferred {amount} from {from_account} to {to_account} for {purpose}.")
            return redirect(url_for('dashboard'))

        return render_template('transfer.html')
    return redirect(url_for('login'))


# logout Route
@app.route('/logout')
def logout():
    session.clear()  # Clear session data
    return redirect(url_for('login'))  # Redirect to login page


if __name__ == '__main__':
    app.run(debug=True)
