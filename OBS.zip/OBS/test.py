import MySQLdb

db = MySQLdb.connect(host='localhost', user='root', passwd='123', db='banking')
cursor = db.cursor()
cursor.execute("SELECT VERSION()")
data = cursor.fetchone()
print("Database version : %s " % data)
db.close()

from flask import Flask, render_template, request, redirect, url_for, session
from flask_bcrypt import Bcrypt
from flask_mysqldb import MySQL
import MySQLdb.cursors
import os
import base64
from random import randint
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from email.mime.text import MIMEText
from dotenv import load_dotenv
import logging

print(os.getenv('MYSQL_USER'))  # Should output 'root'
print(os.getenv('MYSQL_PASSWORD'))  # Should output '123'